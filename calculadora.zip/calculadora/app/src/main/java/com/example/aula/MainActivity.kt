package com.example.aula

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val numa = findViewById<EditText>(R.id.numa)
        val numb = findViewById<EditText>(R.id.numb)
        val resultado = findViewById<TextView>(R.id.resultado)
        val somabut = findViewById<Button>(R.id.soma)
        val subbut = findViewById<Button>(R.id.subtracao)
        val multibut = findViewById<Button>(R.id.multi)
        val divbut = findViewById<Button>(R.id.divisao)

        // Função para converter a entrada em Int ou Double
        fun parse(input: String): Number? {
            return try {
                if (input.contains(".")) {
                    input.toDoubleOrNull()
                } else {
                    input.toIntOrNull() ?: input.toDoubleOrNull()
                }
            } catch (e: NumberFormatException) {
                null
            }
        }

        somabut.setOnClickListener {
            val a = parse(numa.text.toString())
            val b = parse(numb.text.toString())

            if (a != null && b != null) {
                val res = a.toDouble() + b.toDouble()
                resultado.text = "Resultado: $res"
            } else {
                resultado.text = "Insira números válidos!"
            }
        }

        subbut.setOnClickListener {
            val a = parse(numa.text.toString())
            val b = parse(numb.text.toString())

            if (a != null && b != null) {
                val res = a.toDouble() - b.toDouble()
                resultado.text = "Resultado: $res"
            } else {
                resultado.text = "Insira números válidos!"
            }
        }

        multibut.setOnClickListener {
            val a = parse(numa.text.toString())
            val b = parse(numb.text.toString())

            if (a != null && b != null) {
                val res = a.toDouble() * b.toDouble()
                resultado.text = "Resultado: $res"
            } else {
                resultado.text = "Insira números válidos!"
            }
        }

        divbut.setOnClickListener {
            val a = parse(numa.text.toString())
            val b = parse(numb.text.toString())

            if (a != null && b != null) {
                if (b.toDouble() != 0.0) {
                    val res = a.toDouble() / b.toDouble()
                    resultado.text = "Resultado: $res"
                } else {
                    resultado.text = "Impossível dividir por zero!"
                }
            } else {
                resultado.text = "Insira números válidos!"
            }
        }
    }
}
